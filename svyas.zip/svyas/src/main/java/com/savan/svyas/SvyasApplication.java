package com.savan.svyas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SvyasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SvyasApplication.class, args);
	}

}
